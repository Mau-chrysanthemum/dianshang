<template>
    <div>
        欢迎使用品优购电商后台管理系统
    </div>
</template>
