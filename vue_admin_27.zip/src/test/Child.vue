<template>
    <div id="child">
        <!-- <p style="color:red;">我是子组件</p> -->
        <!-- slot是一个占位符 -->
        <slot></slot>
        <!-- <slot name="footer"></slot> -->
    </div>
</template>
